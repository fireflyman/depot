module WillPaginate
  module VERSION
    MAJOR = 2
    MINOR = 3
    TINY  = 12

    STRING = [MAJOR, MINOR, TINY].join('.')
  end
end
