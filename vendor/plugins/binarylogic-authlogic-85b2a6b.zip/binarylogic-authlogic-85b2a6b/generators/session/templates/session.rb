class <%= class_name %> < Authlogic::Session::Base
end