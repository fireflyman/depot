class EmployeeSession < Authlogic::Session::Base
end