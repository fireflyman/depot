class Ldaper < ActiveRecord::Base
  acts_as_authentic
end