require File.dirname(__FILE__) + '/../test_helper.rb'

module SessionTest
  class CallbacksTest < ActiveSupport::TestCase
  end
end